#pragma once

namespace Clumsy
{
	double GetTime();
}