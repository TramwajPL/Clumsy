#pragma once

#include <yaml.h>
#include <glm/glm.hpp>
#include "GameObject.h"

namespace Clumsy {
	class Parser {
	public:
		static void SceneParser(std::string name);
	private:
	};
}