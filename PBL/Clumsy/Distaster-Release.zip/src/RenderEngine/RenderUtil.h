#pragma once

namespace Clumsy {
	class RenderUtil {

	public:
		static void ClearScreen();
		static void InitGraphics();
	};
}